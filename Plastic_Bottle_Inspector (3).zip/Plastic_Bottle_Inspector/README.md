# AI Plastic Bottle Inspector

A student proof-of-concept web app for image-based plastic bottle inspection.

## Files
- `index.html` — page structure and AI library imports
- `style.css` — responsive styling
- `script.js` — image upload, phone camera, model loading and predictions

## Open in Visual Studio Code
1. Extract the ZIP.
2. In VS Code, choose **File → Open Folder** and select `Plastic_Bottle_Inspector`.
3. Install the **Live Server** extension (by Ritwick Dey) if you do not already have it.
4. Right-click `index.html` and choose **Open with Live Server**.
5. The page should open in your browser.

## Connect the AI model later
1. Train an image classification model at https://teachablemachine.withgoogle.com/
2. Use these four classes: `Normal Bottle`, `Missing Cap`, `Label Defect`, and `Bottle Defect` (or use the exact class names agreed by your team).
3. Export the model using **TensorFlow.js** and upload/host it through Teachable Machine.
4. Copy the model URL (it should look like `https://teachablemachine.withgoogle.com/models/XXXXXXXXX/`).
5. Paste it into the model URL field in this app and click **Load model**.

The model URL is intentionally left blank until your own trained model is ready.

## Phone camera
Camera access generally requires HTTPS or `localhost`. For phone testing, use a secure/local access method. The phone and laptop may need to be on the same Wi-Fi, depending on the method used.

## Important limitations
- This is a prototype, not a certified industrial inspection system.
- Image classification depends on the quality and balance of the training images.
- Use consistent, clear bottle photos. Test with separate bottles not used in training.
- The app's PASS/DEFECT wording is a simple mapping from the model's predicted class. Verify the exact class names and decision logic after training.
- No PLC, conveyor, automatic rejection, or factory integration is implemented in this prototype.
