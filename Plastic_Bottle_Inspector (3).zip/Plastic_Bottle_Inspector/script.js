let model = null;
let cameraStream = null;
let selectedImage = null;

const modelUrlInput = document.getElementById("modelUrl");
const modelStatus = document.getElementById("modelStatus");
const imageInput = document.getElementById("imageUpload");
const preview = document.getElementById("preview");
const camera = document.getElementById("camera");
const canvas = document.getElementById("captureCanvas");
const emptyState = document.getElementById("emptyState");

const resultBadge = document.getElementById("resultBadge");
const resultTitle = document.getElementById("resultTitle");
const resultText = document.getElementById("resultText");
const predictions = document.getElementById("predictions");

const captureBtn = document.getElementById("captureBtn");
const inspectBtn = document.getElementById("inspectBtn");
const stopCameraBtn = document.getElementById("stopCameraBtn");

document.getElementById("loadModelBtn").addEventListener("click", loadModel);
imageInput.addEventListener("change", handleUpload);
document.getElementById("startCameraBtn").addEventListener("click", startCamera);
captureBtn.addEventListener("click", capturePhoto);
stopCameraBtn.addEventListener("click", stopCamera);
inspectBtn.addEventListener("click", inspectBottle);

async function loadModel() {
    const url = modelUrlInput.value.trim();

    if (!url) {
        modelStatus.textContent = "Please enter your model URL.";
        return;
    }

    try {
        modelStatus.textContent = "Loading AI model...";

        const normalized = url.endsWith("/") ? url : url + "/";

        model = await tmImage.load(
            normalized + "model.json",
            normalized + "metadata.json"
        );

        modelStatus.textContent = "AI model loaded successfully!";
        updateInspectButton();

    } catch (error) {
        modelStatus.textContent = "Model loading failed. Check your URL.";
        console.error(error);
    }
}

function handleUpload(event) {
    const file = event.target.files[0];

    if (!file) return;

    stopCamera();

    const reader = new FileReader();

    reader.onload = function () {
        preview.src = reader.result;
        preview.hidden = false;
        camera.hidden = true;
        emptyState.hidden = true;

        selectedImage = preview;

        preview.onload = function () {
            updateInspectButton();
            resetResult();
        };
    };

    reader.readAsDataURL(file);
}

async function startCamera() {
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "environment" },
            audio: false
        });

        camera.srcObject = cameraStream;
        camera.hidden = false;
        preview.hidden = true;
        emptyState.hidden = true;

        captureBtn.disabled = false;
        stopCameraBtn.disabled = false;

    } catch (error) {
        resultText.textContent =
            "Camera unavailable. Allow camera permission or use image upload.";

        console.error(error);
    }
}

function capturePhoto() {
    if (!cameraStream) return;

    canvas.width = camera.videoWidth;
    canvas.height = camera.videoHeight;

    canvas.getContext("2d").drawImage(
        camera,
        0,
        0,
        canvas.width,
        canvas.height
    );

    preview.src = canvas.toDataURL("image/png");
    preview.hidden = false;
    camera.hidden = true;

    selectedImage = preview;

    preview.onload = function () {
        updateInspectButton();
        resetResult();
    };
}

function stopCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
    }

    cameraStream = null;
    camera.srcObject = null;
    camera.hidden = true;

    captureBtn.disabled = true;
    stopCameraBtn.disabled = true;
}

function updateInspectButton() {
    inspectBtn.disabled = !(model && selectedImage);
}

function resetResult() {
    resultBadge.textContent = "READY";
    resultBadge.className = "result-badge waiting";

    resultTitle.textContent = "Ready to inspect";
    resultText.textContent = "Click Inspect bottle to analyse the image.";

    predictions.innerHTML =
        '<p class="muted small">Predictions will appear here after inspection.</p>';
}

async function inspectBottle() {
    if (!model || !selectedImage) return;

    resultBadge.textContent = "CHECKING";
    resultTitle.textContent = "Inspecting bottle...";
    resultText.textContent = "Please wait.";
    inspectBtn.disabled = true;

    try {
        const prediction = await model.predict(selectedImage);

        prediction.sort((a, b) => b.probability - a.probability);

        const top = prediction[0];
        const name = top.className.toLowerCase();

        predictions.innerHTML = prediction.map(p =>
            `<div>${escapeHtml(p.className)}: ${(p.probability * 100).toFixed(1)}%</div>`
        ).join("");

        if (/normal|good|pass/.test(name)) {
            resultBadge.textContent = "PASS";
            resultBadge.className = "result-badge pass";
            resultTitle.textContent = "Bottle passed inspection";
            resultText.textContent = "No target defect class was detected.";
        }
        else if (/cap|label|defect|damage|deform/.test(name)) {
            resultBadge.textContent = "DEFECT";
            resultBadge.className = "result-badge defect";
            resultTitle.textContent = "Potential defect detected";
            resultText.textContent = "Predicted defect: " + top.className;
        }
        else {
            resultBadge.textContent = "REVIEW";
            resultBadge.className = "result-badge waiting";
            resultTitle.textContent = "Manual review recommended";
            resultText.textContent = "Predicted class: " + top.className;
        }

    } catch (error) {
        resultBadge.textContent = "ERROR";
        resultTitle.textContent = "Inspection failed";
        resultText.textContent = "Please check your model and image.";
        console.error(error);
    }

    updateInspectButton();
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, ch => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[ch]);
}
